#include <algorithm>
#include <functional>
#include <random>
#include <vector>

#include "Neuron.h"

// Set up a normally distributed random number generator: mean = 0.0, stddev = 1.0
std::random_device Neuron::s_seed;
std::default_random_engine Neuron::s_eng = std::default_random_engine(s_seed());
std::normal_distribution<double> Neuron::s_generator = std::normal_distribution<double>(0.0, 1.0);

// Initialize hyperparameters
double Neuron::s_alpha = 0.0001;
double Neuron::s_lambda = 0.0;

Neuron::Neuron() : m_activationFunc([] (const double x) {return std::max(0.0, x);}), 
    m_activationFuncDerivative([] (const double x) {return (x > 0.0) ? 1.0 : 0.0;})
{
    // Default to ReLU for activation function
    // To-do: overload constructor for other activation functions
}

void Neuron::initConnections(Layer& prevLayer, const unsigned nextLayerSize, const unsigned batchSize)
{   
    // Set up connection vectors for the calling neuron
    m_inputs.reserve(prevLayer.size());
    m_outputs.reserve(nextLayerSize);

    for (Neuron& k : prevLayer) {
        // These connections are input into the calling neuron
        // Xavier initialization is used for the weights (ReLU variation)
        m_inputs.emplace_back(&k, this, s_generator(s_eng) * sqrt(2.0/prevLayer.size()), batchSize);
        
        // These connections are output from neurons in the previous layer
        k.m_outputs.emplace_back(&m_inputs.back());
    }

    return;
}

void Neuron::feedForward() 
{
    m_inputVal = 0.0;
    for (Connection& c : m_inputs) m_inputVal += c.inputNeuron->m_outputVal * c.weight;
    // a = g(a_0*w_0 + a_1*w_1 + ... + a_n-1*w_n-1 + a_n*w_n + b)
    m_outputVal = m_activationFunc(m_inputVal);
    return;
}

void Neuron::calcOutputActivationGradient(const double targetVal)
{
    // dC_i/da_j = 2(a_j - y_j)
    m_activationGradient = 2 * (m_outputVal - targetVal);
    return;
}

void Neuron::calcHiddenActivationGradient() 
{
    m_activationGradient = 0.0;
    for (Connection* c : m_outputs) {
        // dC_i/da_k = (sum j = 1 -> n)(dC_i/da_j * da_j/dz_j * dz_j/da_k)
        m_activationGradient += c->outputNeuron->m_activationGradient * 
            c->outputNeuron->m_activationFuncDerivative(c->outputNeuron->m_inputVal) *
            c->weight;
    }
    return;
}

void Neuron::calcInputWeightGradients()
{
    for (Connection& c : m_inputs) {
        // dC_i/dw_jk = dC_i/da_j * da_j/dz_j * dz_j/dw_jk
        c.recentWeightGradients[c.weightGradientIndex] = 
            m_activationGradient * m_activationFuncDerivative(m_inputVal) * c.inputNeuron->m_outputVal;
        c.weightGradientIndex++;
    }
        
    return;
}

void Neuron::updateInputWeights()
{
    for (Connection& c : m_inputs) {
        // dJ/dw_jk = (1 / m) * ((sum i = 1 -> m) dC_i/dw_jk + lambda * w_jk)
        
        // Sum the weight gradients in this batch
        double sumWeightGradients = 0.0;
        for (double weightGradient : c.recentWeightGradients) sumWeightGradients += weightGradient;

        // Update the weight
        // w_jk = w_jk - alpha * dJ/dw_jk
        c.weight -= (s_alpha / c.recentWeightGradients.size()) * (sumWeightGradients + s_lambda * c.weight);

        // Reset assignment index
        c.weightGradientIndex = 0;
    }

    return;
}
