#include <algorithm>
#include <fstream>
#include <future>
#include <iostream>
#include <iterator>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

// OpenCV was used for a rudimentary image display function during testing. It has not been included in the deployed
// project for simplicity's sake.
// #include <opencv2/core.hpp>
// #include <opencv2/opencv.hpp>

#include "MnistData.cpp"
#include "Network.cpp"
#include "Neuron.cpp"
#include "Timer.cpp"

static void help()
{
    std::cout << 
        "\n------------------------------------------------------------------------------------------" << std::endl <<
        "This program allows for experimentation with fully connected neural networks. The network " << std::endl << 
        "will be trained to classify handwritten digits from the MNIST database " << std::endl <<
        "(http://yann.lecun.com/exdb/mnist/). The network has 784 inputs, which is the number of " << std::endl <<
        "pixels in each input image (28x28), and 10 outputs, from one-hot encoding each digit from " << std::endl <<
        "0 to 9. The user may experiment with the following hyperparameters: the number of hidden " << std::endl <<
        "layers, the number of neurons in each hidden layer, the training batch size, the number of " << std::endl <<
        "epochs, the learning rate, and the regularization parameter. The user may also specify the " << std::endl <<
        "number of networks to train. The program will output the greatest accuracy among networks " << std::endl <<
        "and the mean accuracy, the mean training time, and the mean processing time from all the " << std::endl << 
        "networks.\n" << std::endl <<
        "Usage:" << std::endl <<
        "Main.exe <networkTopology> , <batchSize> <epochs> <numberOfNetworksToTrain> <learningRate>  " << std::endl <<
        "<regularizationParameter>\n" << std::endl <<
        "<networkTopology> is a list of positive integers representing the number of neurons in " << std::endl << 
        "each hidden layer. For example, inputting '16 16' for the network topology would result " << std::endl << 
        "in a network with 2 hidden layers, each containing 16 neurons." << std::endl <<
        "------------------------------------------------------------------------------------------\n" << std::endl;
    
    return;
}

static std::mutex networksRemainingMutex;

static void trainAndTestNetworkMnist(Network* const myNetwork, const unsigned epochs, unsigned* const networksRemaining, 
    const MnistData* const data, std::vector<double>* const modelResults);
static void displayImage(const std::vector<double>& imageData);

int main(const int argc, const char** argv)
{   
    help();
    
    // Set input defaults
    std::vector<int> inputTopology = {784, 16, 16, 10};
    std::vector<int> intInputs = {1, 1, 1};     // batch size, epochs, trials
    double inputAlpha = 0.0001;
    double inputLambda = 0.0;

    if (argc == 1) {
        std::cout << "Default training configuration:" << std::endl;
    }
    // User input validation
    else {
        unsigned topologyLength;
        for (topologyLength = 1; topologyLength < argc; topologyLength++) {
            std::string inputStr(argv[topologyLength]);
            if (inputStr == ",") break;
        }

        if (topologyLength == argc) {
            std::cout << "Error reading input. Please terminate the network topology with a comma." << std::endl;
            return -1;
        }

        if (argc - (topologyLength + 1) > intInputs.size() + 2) {
            std::cout << "Error reading input. Too many arguments." << std::endl;
            return -1;
        }

        // Read in the network topology
        inputTopology.clear();
        inputTopology.reserve(topologyLength); 
        inputTopology.emplace_back(784);
        std::stringstream s;
        for (unsigned i = 1; i < topologyLength; i++) {
            s << argv[i];
            inputTopology.emplace_back();
            s >> inputTopology.back();
            if (!s || inputTopology.back() < 1) {
                std::cout << "Error reading input. Topology may contain only positive integers." << std::endl;
                return -1;
            }
            // Reset string stream
            s.clear();
            s.str("");
        }
        inputTopology.emplace_back(10);

        // Determine the number of remaing arguments
        int remainingArgs = argc - (topologyLength + 1);
        const int intArgs = (remainingArgs > 3) ? 3 : remainingArgs;
        
        // Read in the batch size, epochs, and number of trials if provided
        for (unsigned i = 0; i < intArgs; i++) {
            s << argv[i + (topologyLength + 1)];
            s >> intInputs[i];
            if (!s || intInputs[i] < 1) {
                std::cout << "Error reading input. Argument " << i + (topologyLength + 1) << 
                    " must be a positive integer." << std::endl;
                return -1;
            }
            // Reset string stream
            s.clear();
            s.str("");
        }

        // Read in the learning rate if provided
        if (remainingArgs - intArgs > 0) {
            s << argv[(topologyLength + 1) + intArgs];
            s >> inputAlpha;
            if (!s || !(inputAlpha > 0)) {
                std::cout << "Error reading input. The learning rate must be a positive number." << std::endl;
                return -1;
            }
            // Reset string stream
            s.clear();
            s.str("");
        }

        // Read in the regularization parameter if provided
        if (remainingArgs - intArgs > 1) {
            s << argv[(topologyLength + 1) + intArgs + 1];
            s >> inputLambda;
            if (!s || inputLambda < 0) {
                std::cout << "Error reading input. The regularization parameter must be a number greater than or " << 
                    "equal to 0.0." << std::endl;
                return -1;
            }
            // Reset string stream
            s.clear();
            s.str("");
        }

        std::cout << "Custom training configuration:" << std::endl;
    }

    // Output neural network configuration
    std::cout << "\tNetwork Topology =\t\t";
    for (unsigned i = 0; i < inputTopology.size(); i++) std::cout << inputTopology[i] << " ";
    std::cout << std::endl << 
        "\tBatch Size =\t\t\t" << intInputs[0] << std::endl << 
        "\tEpochs =\t\t\t" << intInputs[1] << std::endl <<
        "\tNumber of Networks =\t\t" << intInputs[2] << std::endl <<
        "\tLearning Rate =\t\t\t" << inputAlpha << std::endl <<
        "\tRegularization Parameter =\t" << inputLambda << "\n" << std::endl;

    // Import the MNIST data
    MnistData data;
    if (!data.getDataValid()) {
        std::cout << "MINST data not available. Program terminated. Press Enter to close." << std::endl;
        std::cin.get();
        return -1;
    }

    // Start a timer to measure performance
    Timer programTimer;

    // Set up neural networks
    const std::vector<unsigned> networkTopology(inputTopology.begin(), inputTopology.end());
    const unsigned batchSize = intInputs[0];
    const unsigned epochs = intInputs[1];
    const unsigned modelTrials = intInputs[2];
    unsigned networksRemaining = modelTrials;
    Neuron::setAlpha(inputAlpha);
    Neuron::setLambda(inputLambda);

    std::vector<Network> myNetworks;
    std::vector<std::vector<double>> modelResults;
    std::vector<std::future<void>> networkFutures;

    myNetworks.reserve(modelTrials);
    modelResults.reserve(modelTrials);
    networkFutures.reserve(modelTrials);

    // Train the networks asynchronously
    for (unsigned i = 0; i < modelTrials; i++) {
        myNetworks.emplace_back(networkTopology, batchSize);
        modelResults.emplace_back();
        networkFutures.emplace_back(std::async(std::launch::async, trainAndTestNetworkMnist, 
            &myNetworks[i], epochs, &networksRemaining, &data, &modelResults[i]));
    }
    std::cout << "Training network(s)..." << std::endl;
    for (std::future<void>& i : networkFutures) i.wait();
    std::cout << std::endl;
    double programExecutionTime = programTimer.getElapsedSeconds();

    // Output performance data
    double maxAcc = 0.0;
    std::vector<double> dataMeans(3, 0.0);
    for (unsigned i = 0; i < modelResults.size(); i++) {
        if (modelResults[i][1] > maxAcc) maxAcc = modelResults[i][1];
        for (unsigned j = 0; j < modelResults[i].size(); j++) dataMeans[j] += modelResults[i][j];
    }
    for (unsigned i = 0; i < dataMeans.size(); i++) dataMeans[i] /= modelResults.size();
    std::cout << "Maximum accuracy:\t" << maxAcc << " %" << std::endl;
    std::cout << "Mean Training Time:\t" << dataMeans[0] << " seconds" << std::endl;
    std::cout << "Mean Accuracy:\t\t" << dataMeans[1] << " %" << std::endl;
    std::cout << "Mean Processing Time:\t" << dataMeans[2] << " milliseconds\n" << std::endl;

    // Output performance data to a csv file
    // This was used during testing for ease of data collection.
    /*
    std::ofstream outputStream("output.csv");
    if (outputStream.is_open()) {
        outputStream << "Program Execution Time," << programExecutionTime << "\n";
        std::string rowHeaders[] = {"Training Time", "Accuracy", "Mean Processing Time"};
        for (unsigned i = 0; i < modelResults[0].size(); i++) {
            outputStream << rowHeaders[i] << ",";
            for (unsigned j = 0; j < modelResults.size(); j++) outputStream << modelResults[j][i] << ",";
            outputStream << "\n";
        }
        outputStream.close();
    }
    else std::cout << "The output file could not be opened." << std::endl;
    */

   std::cout << "Press Enter to close the program." << std::endl;
   std::cin.get();

    return 0;
}

static void trainAndTestNetworkMnist(Network* const myNetwork, const unsigned epochs, unsigned* const networksRemaining, 
    const MnistData* const data, std::vector<double>* const modelResults)
{
    // We are interested in:
    //  1) the time required to train the network.
    //  2) the accuracy of the network.
    //  3) the mean processing time of the network.
    modelResults->reserve(3);

    // Set up randomization for training data
    std::vector<unsigned> indices;
    indices.reserve(data->m_trainingLabels.size());
    for (unsigned i = 0; i < data->m_trainingLabels.size(); i++) indices.emplace_back(i);
    std::random_device seed;
    std::default_random_engine eng(seed());

    // Start a timer to measure performance
    Timer trainingTimer;
    
    // Train the network
    for (unsigned i = 0; i < epochs; i++) {
        // Randomize the training data for each epoch
        std::shuffle(indices.begin(), indices.end(), eng);
        for (unsigned j = 0; j < data->m_trainingLabels.size(); j++) {
            myNetwork->feedForward(data->m_trainingImages[indices[j]]);
            myNetwork->backPropagate(data->m_trainingLabels[indices[j]]);
        }
    }
    // Store the training time
    modelResults->emplace_back(trainingTimer.getElapsedSeconds());

    // Assess the test data
    std::vector<double> networkResults;
    unsigned misclassifications = 0;
    for (unsigned i = 0; i < data->m_testImages.size(); i++) {
        myNetwork->feedForward(data->m_testImages[i]);
        myNetwork->getResults(networkResults);
        if (std::distance(networkResults.begin(), 
            std::max_element(networkResults.begin(), networkResults.end())) != data->m_testLabels[i])
            misclassifications++;
    }
    // Store the accuracy
    modelResults->emplace_back(100.0 * (data->m_testLabels.size() - misclassifications) / data->m_testLabels.size());

    // Determine average processing time
    Timer processingTimer;
    for (const std::vector<double>& image : data->m_trainingImages) myNetwork->feedForward(image);
    for (const std::vector<double>& image : data->m_testImages) myNetwork->feedForward(image);
    modelResults->emplace_back(
        processingTimer.getElapsedMilliseconds() / (data->m_trainingImages.size() + data->m_testImages.size()));

    // Log progress
    std::lock_guard<std::mutex> lock(networksRemainingMutex);
    std::string notification = "Netowork trained! " + std::to_string(--*networksRemaining) + " networks remain.\n";
    std::cout << notification;
}

// This is a quick-and-dirty tool that uses OpenCV to display images to the user.
/*
static void displayImage(const std::vector<double>& imageData)
{
    unsigned rows = 28;
    unsigned cols = 28;
    unsigned pixels = rows * cols;
    cv::Mat image(rows, cols, CV_8U);
    uchar* ptr = image.ptr<uchar>(0);
    for (unsigned i = 0; i < pixels; i++) ptr[i] = imageData[i];
    imshow("", image);
    cv::waitKey(0);
    return;
}
*/
