#include <vector>

#include "Network.h"

Network::Network(const std::vector<unsigned>& topology, const unsigned t_batchSize) 
    : m_batchSize(t_batchSize), m_batchSamples(0)
{
    // topology = {# neurons in layer 0, # neurons in layer 1, ..., # neurons in layer n-1, # neurons in layer n}
    
    // Bias in this network will be modeled as an additional neuron in each layer. This neuron will have no input
    // neurons and a constant activation of 1.0. It will be connected to each neuron in the following layer and each
    // connection will have a learnable weight.
    double biasNeuronOutput = 1.0;
    
    // Set up the layer vector
    m_layers.reserve(topology.size());

    // Add the input layer
    m_layers.emplace_back();
    m_layers.back().reserve(topology[0] + 1);
    for (unsigned n = 0; n < topology[0] + 1; n++) {
        m_layers.back().emplace_back();
        // The input layer has no previous layer, so an empty layer is passed as a parameter to initilize its 
        // neuron's connections.
        m_layers.back().back().initConnections(Layer(), topology[1], m_batchSize);
    }
    // Set the activation of the bias neuron for the input layer.
    m_layers.back().back().setOutputVal(biasNeuronOutput);
    
    // Add the hidden layers
    for (unsigned l = 1; l < topology.size() - 1; l++) {
        m_layers.emplace_back();
        m_layers.back().reserve(topology[l] + 1);
        for (unsigned n = 0; n < topology[l]; n++) {
            m_layers.back().emplace_back();
            m_layers.back().back().initConnections(m_layers[l - 1], topology[l + 1], m_batchSize);
        }
        // Add a bias neuron for each hidden layer
        m_layers.back().emplace_back();
        // The bias neuron will not receive input from the previous layer, so an empty layer is passed as a parameter 
        // to initilize its connections.
        m_layers.back().back().initConnections(Layer(), topology[l + 1], m_batchSize);
        m_layers.back().back().setOutputVal(biasNeuronOutput);
    }

    // Add the output layer
    m_layers.emplace_back();
    m_layers.back().reserve(topology.back() + 1);
    for (unsigned n = 0; n < topology.back(); n++) {
        m_layers.back().emplace_back();
        m_layers.back().back().initConnections(m_layers[m_layers.size() - 2], 0, m_batchSize);
    }
    // Add a bias neuron for the output layer. This neuron will not be connected to any other neurons. It only serves
    // as a placeholder to simplify the feed forward and back propagation algorithms.
    m_layers.back().emplace_back();
}

void Network::feedForward(const std::vector<double>& inputVals)
{
    // Set up the network inputs
    for (unsigned i = 0; i < inputVals.size(); i++) m_layers[0][i].setOutputVal(inputVals[i]);
    
    // Feed forward to update the activation for neurons in subsequent layers.
    for (unsigned l = 1; l < m_layers.size(); l++)
        // Bias neurons have constant output, so skip them.
        for (unsigned n = 0; n < m_layers[l].size() - 1; n++) m_layers[l][n].feedForward();
    
    return;
}

void Network::backPropagate(const std::vector<double>& targetVals)
{
    // Calculate gradients for the output layer
    for (unsigned n = 0; n < targetVals.size(); n++) {
        m_layers.back()[n].calcOutputActivationGradient(targetVals[n]);
        m_layers.back()[n].calcInputWeightGradients();
    }
    
    // Calculate gradients for the hidden layers
    for (unsigned l = m_layers.size() - 2; l > 0; l--) {
        // Bias neurons don't have input connections, so skip them.
        for (unsigned n = 0; n < m_layers[l].size() - 1; n++) {
            m_layers[l][n].calcHiddenActivationGradient();
            m_layers[l][n].calcInputWeightGradients();
        }
    }

    // Increment the number of samples processed in this batch
    m_batchSamples++;
    if (m_batchSamples == m_batchSize) {
        // Reset the sample count for the batch
        m_batchSamples = 0;
        
        // Update the input weights for each neuron in the hidden layers and the output layer.
        for (unsigned l = 1; l < m_layers.size(); l++) {
            // Bias neurons don't have input connections, so skip them.
            for (unsigned n = 0; n < m_layers[l].size() - 1; n++)
                m_layers[l][n].updateInputWeights();
        }
    }

    return;
}

void Network::getResults(std::vector<double>& resultVals) const
{
    resultVals.clear();
    // Ignore the bias neuron
    resultVals.reserve(m_layers.back().size() - 1);
    for (unsigned n = 0; n < m_layers.back().size() - 1; n++) resultVals.emplace_back(m_layers.back()[n].getOutoutVal());
    return;
}
