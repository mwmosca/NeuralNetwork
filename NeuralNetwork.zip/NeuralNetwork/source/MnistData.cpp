#include <cmath>
#include <fstream>
#include <future>
#include <iostream>
#include <vector>

#include "MnistData.h"

MnistData::MnistData() : m_dataValid(false)
{
    std::vector<std::future<bool>> fileFutures;
    fileFutures.reserve(3);
    
    std::cout << "Loading and pre-processing MNIST data..." << std::endl;
    fileFutures.emplace_back(std::async(std::launch::async, &MnistData::readMnistTrainLabelFile, this));
    // The mean and standard deviation of the training image data are calculated as the data is read. These measures
    // are then used to standardize the data before it is passed into the neural network.
    fileFutures.emplace_back(std::async(std::launch::async, &MnistData::readMnistTrainImageFile, this));
    fileFutures.emplace_back(std::async(std::launch::async, &MnistData::readMnistTestLabelFile, this));
    for (std::future<bool>& i : fileFutures) i.wait();
    
    // The training image data must be completely read in before reading in the test image data. The mean and standard
    // deviation of the training data will also be used to standardize the test image data.
    bool overallSatus = readMnistTestImageFile();

    for (std::future<bool>& i : fileFutures) overallSatus = overallSatus && i.get();
    m_dataValid = overallSatus;
    if (m_dataValid) std::cout << "MNIST data loaded and pre-processed!" << std::endl;
    else std::cout << "MNIST data failed to load." << std::endl;
}

bool MnistData::readMnistTrainLabelFile()
{
    bool status = false;

    // Open the file containing the labels for the training images
    std::ifstream inputStream("train-labels.idx1-ubyte", std::ios::binary);

    if (inputStream.is_open()) {
        unsigned intReader = 0;
        unsigned numSamples = 0;
        unsigned char charReader = 0;
        
        // Read in the magic number
        inputStream.read((char*) &intReader, sizeof(intReader));
        
        // Read in the number of samples
        inputStream.read((char*) &intReader, sizeof(intReader));
        // Swap from high to low endian
        numSamples = _byteswap_ulong(intReader);
        
        // Read in the labels using one-hot encoding
        m_trainingLabels.reserve(numSamples);
        for (unsigned i = 0; i < numSamples; i++) {
            inputStream.read((char*) &charReader, sizeof(charReader));
            m_trainingLabels.emplace_back(std::vector<double> {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0});
            m_trainingLabels.back()[charReader] = 1.0;
        }

        inputStream.close();
        status = true;
    }

    return status;
}

bool MnistData::readMnistTrainImageFile()
{
    bool status = false;
    
    // Open the file containing the training image data
    std::ifstream inputStream("train-images.idx3-ubyte", std::ios::binary);

    if (inputStream.is_open()) {
        unsigned intReader = 0;
        unsigned numSamples = 0;
        unsigned rows = 0;
        unsigned cols = 0;
        unsigned pixelCount = 0;
        unsigned char charReader = 0;

        // Read in the magic number
        inputStream.read((char*) &intReader, sizeof(intReader));

        // Read in the number of image samples
        inputStream.read((char*) &intReader, sizeof(intReader));
        // Swap from high to low endian
        numSamples = _byteswap_ulong(intReader);

        // Read in the image pixel dimensions
        inputStream.read((char*) &intReader, sizeof(intReader));
        rows = _byteswap_ulong(intReader);
        inputStream.read((char*) &intReader, sizeof(intReader));
        cols = _byteswap_ulong(intReader);
        pixelCount= rows * cols;

        // Read in image data
        m_trainingImages.reserve(numSamples);
        m_dataMean.reserve(pixelCount);
        m_dataMean = std::vector<double>(pixelCount, 0.0);
        for (unsigned i = 0; i < numSamples; i++) {
            std::vector<double> imageData;
            imageData.reserve(pixelCount);
            for (unsigned j = 0; j < pixelCount; j++) {
                inputStream.read((char*) &charReader, sizeof(charReader));
                imageData.emplace_back(charReader);
                m_dataMean[j] += charReader;
            }
            m_trainingImages.emplace_back(imageData);
        }

        inputStream.close();
        
        // Standardize the data for each pixel: mean = 0, standard deviation = 1
        // mean_i = (1 / m) * (sum i = 1 -> m) x_i
        for (unsigned i = 0; i < m_dataMean.size(); i++) m_dataMean[i] /= numSamples;

        // stdDev_i = sqrt((1 / (m - 1)) * (sum i = 1 -> m) (x_i - mean_i)^2)
        m_dataStdDev.reserve(pixelCount);
        m_dataStdDev = std::vector<double>(pixelCount, 0.0);
        for (unsigned i = 0; i < numSamples; i++)
            for (unsigned j = 0; j < pixelCount; j++)
                m_dataStdDev[j] += std::pow((m_trainingImages[i][j] - m_dataMean[j]), 2);

        for (unsigned i = 0; i < m_dataStdDev.size(); i++) 
            m_dataStdDev[i] = (m_dataStdDev[i] == 0.0) ? 1.0 : std::sqrt(m_dataStdDev[i] / (numSamples - 1));

        for (unsigned i = 0; i < numSamples; i++)
            for (unsigned j = 0; j < pixelCount; j++)
                m_trainingImages[i][j] = (m_trainingImages[i][j] - m_dataMean[j]) / m_dataStdDev[j];

        status = true;
    }
    
    return status;
}

bool MnistData::readMnistTestLabelFile() 
{
    bool status = false;
    
    // Open the file containing the labels for the test images
    std::ifstream inputStream("t10k-labels.idx1-ubyte", std::ios::binary);

    if (inputStream.is_open()) {
        unsigned intReader = 0;
        unsigned numSamples = 0;
        unsigned char charReader = 0;
        
        // Read in the magic number
        inputStream.read((char*) &intReader, sizeof(intReader));
        
        // Read in the number of samples
        inputStream.read((char*) &intReader, sizeof(intReader));
        // Swap from high to low endian
        numSamples = _byteswap_ulong(intReader);
        
        // Read in labels
        m_testLabels.reserve(numSamples);
        for (unsigned i = 0; i < numSamples; i++) {
            inputStream.read((char*) &charReader, sizeof(charReader));
            m_testLabels.emplace_back(charReader);
        }

        inputStream.close();
        status = true;
    }

    return status;
}

bool MnistData::readMnistTestImageFile() 
{
    bool status = false;
    
    // Open the file containing the test image data
    std::ifstream inputStream("t10k-images.idx3-ubyte", std::ios::binary);

    if (inputStream.is_open()) {
        unsigned intReader = 0;
        unsigned numSamples = 0;
        unsigned rows = 0;
        unsigned cols = 0;
        unsigned pixelCount = 0;
        unsigned char charReader = 0;

        // Read in the magic number
        inputStream.read((char*) &intReader, sizeof(intReader));

        // Read in the number of image samples
        inputStream.read((char*) &intReader, sizeof(intReader));
        // Swap from high to low endian
        numSamples = _byteswap_ulong(intReader);

        // Read in the image pixel dimensions
        inputStream.read((char*) &intReader, sizeof(intReader));
        rows = _byteswap_ulong(intReader);
        inputStream.read((char*) &intReader, sizeof(intReader));
        cols = _byteswap_ulong(intReader);
        pixelCount= rows * cols;

        // Read in image data
        m_testImages.reserve(numSamples);
        for (unsigned i = 0; i < numSamples; i++) {
            std::vector<double> imageData;
            imageData.reserve(pixelCount);
            for (unsigned j = 0; j < pixelCount; j++) {
                inputStream.read((char*) &charReader, sizeof(charReader));
                // Standardize the data for each pixel using the measures from the training image data: 
                // mean = 0, standard deviation = 1
                imageData.emplace_back((charReader - m_dataMean[j]) / m_dataStdDev[j]);
            }
            m_testImages.emplace_back(imageData);
        }

        inputStream.close();
        status = true;
    }

    return status;
}
