#pragma once

#include <vector>

#include "Neuron.h"

class Network
{
    public:
        Network(const std::vector<unsigned>& topology, const unsigned t_batchSize);
        void feedForward(const std::vector<double>& inputVals);
        void backPropagate(const std::vector<double>& targetVals);
        void getResults(std::vector<double>& resultVals) const;
    private:
        std::vector<Layer> m_layers;
        const unsigned m_batchSize;
        unsigned m_batchSamples;
};
